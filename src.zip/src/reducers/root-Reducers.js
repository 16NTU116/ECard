import {combineReducers} from "redux";
import SkillReducer from "./skills-reducers";

const rootReducers = combineReducers({
    SkillReducer
});

export default rootReducers;
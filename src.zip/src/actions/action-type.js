export const addEmployeeProfile = "Add_Employee_Profile";
export const changeEditSkills = "Change_Skill_Edit";
export const updateSkill = "Update_Skill";
export const deleteSkill = "Delete_Skill";